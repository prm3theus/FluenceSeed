const toStream = require('nanoiterator/to-stream')

class Buffle {
    db
    constructor(db: any){
        this.db = db
    }

    /* 
        
    */
    post = (key: any, val: any) => {
        const self = this
        return new Promise<any>((resolve, reject) => {
            this.db.put(key, val, () => {
                this.db.get(key, (err: any, val: any) => {
                    resolve(val)
                })
            })
        })
    }
    /* 
        
    */
    getReduced = (key: any) => {
        return new Promise<number>((resolve, reject) => {
            const buffer: any = []
            let sum: any = 0
            const stream = toStream(this.db.history({reverse: false}))
            stream.on('data', (data: any) => {
                if(data.key.split(':')[0] == key){
                    buffer.push(data)
                    sum += data.value
                }
            })
            stream.on('end', (end: any) => {
                resolve(sum / buffer.length)
            })
        })
    }
    /* 
        
    */
    getAll = (session: any) => {
        return new Promise<[number]>((resolve, reject) => {
            const buffer: any = []
            const stream = toStream(this.db.history({reverse: false}))
            stream.on('data', (data: any) =>{
                if(data.key.split(':')[0] == session)
                buffer.push(data.value)
            })
            stream.on('end', (end: any) => {
                resolve(buffer)
            })
        })
    }
    /* 

    */
    duplicate = (value: any) => {
        return new Promise<boolean>((resolve, reject) => {
            const stream = toStream(this.db.history({reverse: false}))
            stream.on('data', function (data: any) {
                if(value == data.key) resolve(true)
            })
            stream.on('end', function (end: any) {
                resolve(false)
            })
        })
    }
}

export default Buffle;