
import { Fluence } from "@fluencelabs/fluence";
import { krasnodar } from "@fluencelabs/fluence-network-environment";
import { 
    postReview, 
    getReducedReviews, 
    getAllReviews, 
    registerReviews 
} 
from './generated/reviews';

const toStream = require('nanoiterator/to-stream')
const hypertrie = require('hypertrie')

// Timely chron to post to IPFS and email to hummingfox9@proton.me
const db = hypertrie('./trie.db', {valueEncoding: 'json'})
import Buffle from './Buffle'

async function main() {
    await Fluence.start({
      connectTo: krasnodar[0],
    });

    const buffle = new Buffle(db)

    registerReviews({
        post: async (from, deck, address, rating) => {
            console.log(from)
            return await buffle.post(`${deck}:${address}`, rating)
        },
        getReduced: async (deck) => {
            return await buffle.getReduced(deck)
        },
        getAll: async (session) => {
            return await buffle.getAll(session)
        }
    });
    // registerCalc(new Calc());
    console.log("application started");
    console.log("peer id is: ", Fluence.getStatus().peerId);
    console.log("relay is: ", Fluence.getStatus().relayPeerId);
}

main();