
import { Fluence } from "@fluencelabs/fluence";
import { krasnodar } from "@fluencelabs/fluence-network-environment";
import { 
    postReview, 
    getReducedReviews, 
    getAllReviews
} 
from '../generated/timestamp_getter';

async function main() {
    console.log('dialing in ...')
    await Fluence.start({
      connectTo: krasnodar[0],
    });

    console.log("application started");
    console.log("peer id is: ", Fluence.getStatus().peerId);
    console.log("relay is: ", Fluence.getStatus().relayPeerId);
    console.log("press any key to continue");

    const PEER_ID = process.env.PEER_ID as string
    // const TARGET_RELAY_ID = process.env.TARGET_RELAY_ID as string
    
    // Post to trie
    console.log(await postReview(PEER_ID, Fluence.getStatus().relayPeerId as string, "n3pthora", "0xC0FFEE", 2))
    console.log(await postReview(PEER_ID, Fluence.getStatus().relayPeerId as string, "w1ll0w", "0xC0FFEE", 5))

    // Read from trie
    console.log(await getAllReviews(PEER_ID, Fluence.getStatus().relayPeerId as string,'n3pthora'))
    console.log(await getReducedReviews(PEER_ID, Fluence.getStatus().relayPeerId as string, 'n3pthora'))
    console.log(await getReducedReviews(PEER_ID, Fluence.getStatus().relayPeerId as string, 'w1ll0w'))

    process.exit()
}

main();