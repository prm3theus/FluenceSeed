const toStream = require('nanoiterator/to-stream')
const hypertrie = require('hypertrie')
import Buffle from './Buffle'

// Timely chron to post to IPFS and email to hummingfox9@proton.me
const db = hypertrie('./trie.db', {valueEncoding: 'json'})

async function main() {
    const buf = new Buffle(db)

    console.log(await buf.post('n3pthora:0xC0FFEE', 5))
    console.log(await buf.post('n3pthora:0xC0FFEE', 4))
    console.log(await buf.post('n3pthora:0xC0FFEE', 3))
    // console.log(await buf.post('w1ll0w:0xC0FFEE', 5))
    // console.log(await buf.post('w1ll0w:0xC0FFEE', 2))
    console.log(await buf.getAll('n3pthora'))
    console.log(await buf.getReduced('n3pthora'))
    console.log(await buf.getReduced('w1ll0w'))
    console.log(await buf.duplicate('n3pthora:C0FFEE'))
    console.log(await buf.duplicate('n3pthora:0xdeaf'))
}

main()