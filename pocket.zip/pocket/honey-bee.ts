const Hyperbee = require('hyperbee')

const SDK = require('hyper-sdk')
const hypercore = require('hypercore')

const { tree } = require('hypercore-crypto')
const hyperswarm = require('hyperswarm')
const pump = require('pump')
const crypto = require('crypto')

const express = require('express');
const app = express();
const http = require('http');
const server = http.createServer(app);
const { Server } = require("socket.io");
const io = new Server(server, {
    cors: {
      origin: '*',
    }
});

server.listen(3000, () => {
  console.log('listening on *:3000');
});

async function main() {

    const name = "reed"

    const topic = crypto.createHash('sha256')
        .update('reed')
        .digest()

    const core = new hypercore(name)

    const db = new Hyperbee(core, {
        keyEncoding: 'utf-8', // can be set to undefined (binary), utf-8, ascii or and abstract-encoding
        valueEncoding: 'json' // same options as above
    })

    io.on('connection', (socket) => {
        console.log('emitting')
        core.createReadStream().on('data', (data) => {
            console.log(data)
            console.log(io.of("/").emit("hi", data.toString().split('"')[1]))
        })
        console.log('a user connected');
    });

    setInterval(() => db.put('sho', 'far'), 1000/.75)

    // doesn't work, need some help
    // swarm.join(topic, {client: false, server: true})
    // swarm.on('connected', (connection) => pump(socket, core.replicate(connection), socket) )
}

main()