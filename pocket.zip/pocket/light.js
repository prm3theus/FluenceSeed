const Hypercore = require('hypercore')
const Hyperswarm = require('hyperswarm')
const ram = require('random-access-memory')

const core = new Hypercore('./store', process.argv[2])

start()

async function start () {
  await core.ready()

  const swarm = new Hyperswarm()
  console.log(core.discoveryKey.toString('hex'))
  swarm.on('connection', socket => core.replicate(socket))
  swarm.join(core.discoveryKey, { server: false, client: true })
//   await core.append([1,2,3])
  // console.log((await core.get(0)))
//   console.log((await core.get(2)))

  core.createReadStream({live: true}).on('data', (data) => {
    console.log('data')
    console.log(data.toString())
  })

//   console.log((await core.get(142)).toString())
//   console.log((await core.get(511)).toString())
//   console.log((await core.get(512)).toString())
//   console.log((await core.get(513)).toString())
}