// const Hyperbee = require('hyperbee')
// import { Hyperbee } from 'hyperbee'
// This module handles networking and storage of hypercores for you
// import { SDK } from 'hyper-sdk'
// import { DB } from 'hyperbeedeebee'

const Server = require('./server')

async function main(){
    const port = 4977
    const hostname = `ws://localhost:${port}`
    const server = new Server()
    server.listen(4977)
}

main()
