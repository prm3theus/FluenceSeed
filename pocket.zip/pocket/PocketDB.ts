const toStream = require('nanoiterator/to-stream')

class PocketDB {
    db
    constructor(db: any){
        this.db = db
    }

    /* 
        
    */
    append = (key: any, val: any) => {
        const self = this
        return new Promise<any>((resolve, reject) => {
            this.db.put(`#${key}`, val, () => {
                this.db.get(`#${key}`, (err: any, val: any) => {
                    resolve(true)
                })
            })
        })
    }
    /* 
        
    */
    look = (key: any) => {
        return new Promise<number>((resolve, reject) => {
            const buffer: any = []
            const stream = toStream(this.db.history({reverse: false}))
            stream.on('data', (data: any) => {
                if(data.key == `#${key}`){
                    buffer.push(data.value)
                }
            })
            stream.on('end', (end: any) => {
                resolve(buffer)
            })
        })
    }
    /* 
    
    */
    everything = () => {
        return new Promise<[number]>((resolve, reject) => {
            const buffer: any = []
            const stream = toStream(this.db.history({reverse: false}))
            stream.on('data', (data: any) =>{
                if(data.key.includes('#')) buffer.push(data.value)
            })
            stream.on('end', (end: any) => {
                resolve(buffer)
            })
        })
    }
    post = (key: any, val: any) => {
        const self = this
        return new Promise<any>((resolve, reject) => {
            this.db.put(key, val, () => {
                this.db.get(key, (err: any, val: any) => {
                    resolve(val)
                })
            })
        })
    }
    /* 
        
    */
    getReduced = (session: any) => {
        return new Promise<number>((resolve, reject) => {
            const buffer: any = []
            let sum: any = 0
            const stream = toStream(this.db.history({reverse: false}))
            stream.on('data', (data: any) => {
                if(data.key.split(':')[0] == session){
                    buffer.push(data)
                    sum += data.value
                }
            })
            stream.on('end', (end: any) => {
                console.log(sum / buffer.length)
                console.log(sum)
                console.log(buffer.length)
                resolve(sum / buffer.length)
            })
        })
    }
    /* 
        
    */
    getAll = (session: any) => {
        return new Promise<[number]>((resolve, reject) => {
            const buffer: any = []
            const stream = toStream(this.db.history({reverse: false}))
            stream.on('data', (data: any) =>{
                if(data.key.split(':')[0] == session)
                buffer.push(data.value)
            })
            stream.on('end', (end: any) => {
                resolve(buffer)
            })
        })
    }
    /* 

    */
    duplicate = (key: any) => {
        return new Promise<boolean>((resolve, reject) => {
            const stream = toStream(this.db.history({reverse: false}))
            stream.on('data', function (data: any) {
                if(key != data.key) resolve(true)
            })
            stream.on('end', function (end: any) {
                resolve(false)
            })
        })
    }
}

export default PocketDB;