import {Fluence} from '@fluencelabs/fluence'
import { krasnodar } from '@fluencelabs/fluence-network-environment'
import PocketDB from './PocketDB'
import hypertrie from 'hypertrie'
import { tsMethodSignature } from '@babel/types'
import {
    //line 392, w/ peer
    getRelayTime, // Q: what's the difference between a mark in the urbit hoon programming language and a particle definition with a fluence blueprint?
    
    // line 258 w/ peer
    postReview,

    // line 477 w/ peer
    getReducedReviews,

    // line 592 w/peer
    addDeck,

    /// something here about how this will cost money, so a socket can be a cheaper read
    getAllReviews,

    //line 729 // w/peer
    getUniqueness,

    // 947 // w/no peer, can be switched if secure and consented, or use of music to guide
    deckUnwrap
} from './generated_aqua/reed'

// import { Script } from 'vm'
// const db = hypertrie('./trie.db', {valueEncoding: 'json', alwaysUpdate: true, alwaysReconnect: true, lock: false})

async function main(PEER_ID){
    // const pdb = new PocketDB(db)
    // // test deck upload
    // console.log("Inserting: ", await pdb.append("hod", ["1,2,3","4,5,6"]))
    // console.log("Retrieving: ", await pdb.look("hod"))
    // console.log("Oll-ie", await pdb.everything())
    // const address = '0xca2'

    // console.log(await pdb.post(`n3pthora:${address}`, 5))
    // console.log(await pdb.post(`n3pthora:${address}`, 2))
    // console.log(await pdb.getReduced('n3pthora'))

    await Fluence.start({
        connectTo: krasnodar[0]
        // seedArray: await lir(Vault(true)) // ya true
    })

    console.log(await getRelayTime(Fluence.getStatus().relayPeerId))
    console.log('connected:', Fluence.getStatus().peerId)
    const signature = ""
    // console.log(await postReview(PEER_ID, Fluence.getStatus().relayPeerId,"n3pthora", signature, "0x73A73A",5, {ttl: }))
    var ttl = new Date();
    ttl.setDate(ttl.getDate() + 40);
    /* 

        const ad = await matter.direct.reed.addDeck(PEER_ID, __, ___, ____, _____, "n3pthora", [...|,,|])

    */
    // describe: it should add a deck and return whether the deck is unique
    // targetPeerId: PeerId, targetRelayPeerId: PeerId, address: string, signature: string, title: string, deck: []string
    // const ad = await addDeck(PEER_ID, Fluence.getStatus().relayPeerId, "0x", "signature", "n3pthora", [""], new Date())
    const ad = await addDeck(PEER_ID, Fluence.getStatus().relayPeerId, "0x", "signature", "n3pthora", ["4,0,0"])
    console.log(ad) // true

    // it should get the deck and return a matrix
    // const unW = await deckUnwrap(PEER_ID, Fluence.getStatus().relayPeerId, "n3pthora")
    // console.log(unW)

    // // // console.log(await postReview(PEER_ID, Fluence.getStatus().relayPeerId,"n3pthora", signature, "0x73A73A",5, {ttl: ttl.getMilliseconds()}))
    // const pr =  await postReview(PEER_ID, Fluence.getStatus().relayPeerId,"n3pthora", signature, "0x73A73A",5)

    // await postReview(PEER_ID, Fluence.getStatus().relayPeerId,"n3pthora", signature, "0x73A73A",4)
    // await postReview(PEER_ID, Fluence.getStatus().relayPeerId,"n3pthora", signature, "0x73A73A",3)

    // console.log(pr) // content
    
    // // // describe: it should get an average review rating for a deck
    // const grr = await getReducedReviews(PEER_ID, Fluence.getStatus().relayPeerId, "n3pthora")
    // console.log(grr) // null

    // // get uniqueness
    // const uni = await getUniqueness(PEER_ID, Fluence.getStatus().relayPeerId, "n3pthora")
    // console.log(uni) // false

    // // get uniqueness for something that doesn't exist
    // const uni2 = await getUniqueness(PEER_ID, Fluence.getStatus().relayPeerId, "w1ll0w")
    // console.log(uni2) // false

    // delete a deck
    // TODO

    // postReview -> should return false
    // getReducedReviews -> should return null
    // getUniqueness -> should return true
}

main("12D3KooWK3iPRebrVPEZPAgdSveAo8aAFCYpz91f2LqHU9yvHLq5")

/* TODO
    - write a README
    - create tests for backend in a script, testing Reviews service 
    - integrate front end epxerience 
        - reviews
        - decks
*/

// review -> retroactive funding?