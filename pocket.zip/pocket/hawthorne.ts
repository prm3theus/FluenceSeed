// const Hyperbee = require('hyperbee')
// import { Hyperbee } from 'hyperbee'
// This module handles networking and storage of hypercores for you
// import { SDK } from 'hyper-sdk'
// import { DB } from 'hyperbeedeebee'

// import { DB } from 'hyperbeedeebee'


// const SDK = require('hyper-sdk')
// const {DB} = require('hyperbeedeebee')

async function main(){
    const { Hyperbee } = await import("hyperbee");
    const { SDK } = await import("hyper-sdk");
    const { DB } = await import("hyperbeedeebee");

    const {Hypercore} = new SDK()

    // Initialize a hypercore for loading data
    const core = new Hypercore('example')
    // Initialize the Hyperbee you want to use for storing data and indexes
    const bee = new Hyperbee(core)

    // Create a new DB
    const db = new DB(bee)

    // Open up a collection of documents and insert a new document
    const doc = await db.collection('example').insert({
        hello: 'World!'
    })

    // doc._id gets set to an ObjectId if you don't specify it
    console.log(doc)

}

main()
