// const Hyperbee = require('hyperbee')
// import { Hyperbee } from 'hyperbee'
// This module handles networking and storage of hypercores for you
// import { SDK } from 'hyper-sdk'
// import { DB } from 'hyperbeedeebee'

// import { DB } from 'hyperbeedeebee'


// const SDK = require('hyper-sdk')
// const {DB} = require('hyperbeedeebee')
const Hypercore = require('hypercore')
const Hyperswarm = require('hyperswarm')
const Corestore = require('corestore')
const swarm = new Hyperswarm()

const init = require('./init.js')
const core = new Hypercore('./clone13')
const crypto = require('crypto')
const server = require('./server')
const { Server } = require('http')

async function main(){
    const port = 4977
    const hostname = `ws://localhost:${port}`
    const server = new Server()
    await server.listen(4977)
    // console.log(server)
    const i = await init('./akashic') 

    await i.core.ready()

    const topic = crypto.createHash('sha256')
    .update('reed')
    .digest()

    // const core = new Hypercore(name)

    const swarm = new Hyperswarm({bootstrap: [hostname]})
    console.log(i.core.discoveryKey.toString('hex'))
    console.log(i.core.key.toString('hex'))
    swarm.on('connection', (socket) => {
      i.core.replicate(socket)
    })
    
    swarm.join(i.core.discoveryKey, { server: true, client: false })
    // swarm.join(topic, { server: true, client: false })

  //   core.append([1,2,3])
    let j = 0;
    // Open up a collection of documents and insert a new document
    setInterval(async () => {
        // const doc = await i.db.collection('example').insert({
        //     hello: 'World!'
        // })
        await i.core.append([`${Math.random()}`])
        // console.log((await core.get(j++)))

        // console.log(doc)
    }, 3000)

    i.core.createReadStream({live: true}).on('data', (data) => {
        console.log(data.toString())
    })

    // for await (const data of fullStream) {
    //   console.log('data:', data)
    // }

    // doc._id gets set to an ObjectId if you don't specify it
    const url = `hyper://${i.core.key.toString('hex')}`
  	console.log(url)

}

main()
