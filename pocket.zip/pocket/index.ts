// import fluence
import { Fluence } from "@fluencelabs/fluence";
import { krasnodar } from "@fluencelabs/fluence-network-environment";

// import function registers
// import { registerMatrix, registerReviews} from '../src/generated/reed'; // doesn't work
import { registerMatrix, registerReviews } from './generated_aqua/reed'; // doesn't work
// import { registerChatServer } from '../../reed-v6/my-app/src/generated/Chat'; // doesn't work
// import { registerMatrix } from '../src/generated/reed'; // doesn't work

// import { registerReviews} from '../src/generated/reviews'; // doesn't work
// import { registerMatrix } from './generated_aqua/matrix_decks'; // works

const Hyperbee = require('hyperbee')

const SDK = require('hyper-sdk')
const hypercore = require('hypercore')

const { tree } = require('hypercore-crypto')
const hyperswarm = require('hyperswarm')
const pump = require('pump')
const crypto = require('crypto')

const express = require('express');
// const app = express();
// const http = require('http');
// const server = http.createServer(app);
// const { Server } = require("socket.io");
// const io = new Server(server, {
    // cors: {
    //   origin: '*',
    // }
// });


// database init
import PocketDB from './PocketDB'
import { WebSocketServer } from "ws";

const hypertrie = require('hypertrie')
// const ram = require('random-access-memory')
// const feed = hypercore(ram())
const db = hypertrie('./trie.db', {valueEncoding: 'json', alwaysUpdate: true, alwaysReconnect: true, lock: false})
const pocketDB = new PocketDB(db)
const server = new WebSocketServer({ port: 3001 });


// main runner
async function main(name) {
    
    const core = new hypercore(name)

    const db = new Hyperbee(core, {
        keyEncoding: 'utf-8', // can be set to undefined (binary), utf-8, ascii or and abstract-encoding
        valueEncoding: 'json' // same options as above
    })

    // io.on('connection', (socket) => {
  server.on("connection", async (socket: any) => {

        console.log('emitting')
        db.createHistoryStream({live: true}).on('data', (data) => {
            console.log(data)
            socket.send(JSON.stringify({
                type: "hello from server",
                content: [data.key, data.value] 
            }));

            // console.log(io.of("/").emit("hi", {peerId: data.key, datum: data.value}))
        })

        // setInterval(() => {
        //     // console.log(data)
        //     socket.send(JSON.stringify({
        //         type: "hello from server",
        //         content: ["data.key", "meow"] 
        //     }));
        // }, 2000)
        console.log('a user connected');
    });

    // server.listen(3002, () => {
    //     console.log('listening on *:3000');
    // });

    // setInterval(() => db.put('sho', 'far'), 1000/.75)

    const flu = await Fluence.start({
      connectTo: krasnodar[0],
    });

    console.log("application started");
    console.log("peer id is: ", Fluence.getStatus().peerId);
    console.log("relay is: ", Fluence.getStatus().relayPeerId);

    // register matrix handlers
    registerMatrix({
        append: async (from, signature, address, link, card) => {
            console.log(card)
            return await db.put(link, {from: from, signature: signature, address: address, link: link, card: card, time: Date.now()})
        },
        look: async (from, title) => {
            // const records = await pocketDB.look(title)
            // console.log(records)
            // console.log(records[0])
            console.log('running look')
            console.log(title)
            const deck = await db.get(title)
            console.log(deck.value)
            console.log(typeof deck.value)

            // deck.value.map((el: string) => Number(el.split(',')))
            return deck.value.map((el: string) => Number(el.split(',')))
        }
    });

    // register review handlers
    registerReviews({
        post: async (from, deck, address, rating) => {
            console.log(from)
            db.put(from, rating)
            return await pocketDB.post(`${deck}:${address}`, rating)
        },
        getReduced: async (deck) => {
            console.log('calling get reduced')
            console.log(deck)
            const reduced = await pocketDB.getReduced(deck)
            console.log(reduced)

            if(reduced != null) return await pocketDB.getReduced(deck)
            else return 0
        },
        getAll: async (session) => {
            return await pocketDB.getAll(session)
        },
        isUnique: async (session) => {
            return !(await pocketDB.duplicate(session))
        }
    });

}

main('reed-1');